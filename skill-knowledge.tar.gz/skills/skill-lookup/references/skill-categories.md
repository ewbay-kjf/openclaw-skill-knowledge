# 技能分类和触发指南

## 技能分类

### 1. 核心技能
- 基于 AGENTS.md 中的 <available_skills> 部分
- 主要用于日常操作和常用任务
- 由系统自动加载

### 2. 系统技能
- 安装在 `/usr/lib/node_modules/openclaw/skills/` 目录
- 提供系统级别的功能扩展
- 需要特定的触发条件

### 3. 基础工具能力
- 内置工具：read, write, edit, exec, process, canvas, message 等
- 无需技能触发即可使用
- 是 OpenClaw 的核心功能

## 技能触发原则

### 触发时机
1. **当只有一个技能明确适用时**：读取其 SKILL.md 然后遵循它
2. **当多个可能适用时**：选择最具体的技能，然后读取/遵循它
3. **当没有明确适用时**：不读取任何 SKILL.md

### 技能读取约束
- 从不提前读取超过一个技能
- 只有在确定使用该技能后才读取 SKILL.md

## API 使用约束

- 技能驱动外部 API 写入时：假设有速率限制
- 倾向于更少更大的写入，避免紧密的单项目循环
- 尽可能序列化爆发，尊重 429/Retry-After

## 常用技能触发关键词

### Agent Browser
- 网页浏览、截图、表单填写、DOM 检查、点击、导航
- 网页搜索或获取网页内容
- 不要尝试使用 openclaw browser 命令

### clawhub
- 技能搜索、安装、更新、发布

### find-skills
- 技能、插件、找技能、安装技能、find-skill、find-skills

### github
- GitHub、issue、PR、CI、gh

### healthcheck
- 安全检查、防火墙、SSH、更新加固、风险姿态、暴露检查

### node-connect
- QR/设置代码/手动连接失败、配对问题、gateway.bind、gateway.remote.url

### obsidian
- Obsidian vaults、Markdown 笔记、obsidian-cli

### self-improvement
- 命令失败、用户纠正、能力不存在、API 失败、知识过时

### skill-creator
- 创建技能、作者技能、整理技能、改进技能、审查技能、清理技能

### skillhub-preference
- 技能发现、安装、更新

### summarize
- 摘要、网页、PDF、图片、音频、YouTube

### taskflow
- 任务流程、多步骤工作管理

### taskflow-inbox-triage
- 收件箱分类

### tavily-search
- 网页搜索、查找来源、查找链接

### tencent-cloud-cos
- 腾讯云对象存储、图片处理、文档转PDF、视频封面

### tencent-docs
- 腾讯文档、在线文档、知识库空间

### tencent-meeting-mcp
- 腾讯会议、预约会议、创建会议、会议录制、会议纪要

### tmux
- tmux 会话、远程控制、交互式 CLI

### video-frames
- 视频帧提取、短片剪辑

### weather
- 天气预报、天气查询