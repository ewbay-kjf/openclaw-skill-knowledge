# 技能使用示例

## Agent Browser 示例

**触发**: "帮我搜索一下最新新闻"、"打开网页截图"、"填写表单并提交"

**使用步骤**:
1. 触发 Agent Browser 技能
2. 读取 SKILL.md 获取使用方法
3. 使用浏览器自动化功能完成操作

## Github 示例

**触发**: "查看 GitHub 上的 issue"、"创建一个新的 PR"、"运行 CI 任务"

**使用步骤**:
1. 触发 Github 技能
2. 读取 SKILL.md 获取使用方法
3. 使用 gh CLI 命令进行操作

## Weather 示例

**触发**: "今天天气怎么样"、"查询天气预报"、"明天会下雨吗"

**使用步骤**:
1. 触发 Weather 技能
2. 读取 SKILL.md 获取使用方法
3. 查询天气信息

## Summarize 示例

**触发**: "摘要这个网页"、"PDF 摘要"、"YouTube 视频摘要"

**使用步骤**:
1. 触发 Summarize 技能
2. 读取 SKILL.md 获取使用方法
3. 使用 summarize CLI 处理内容

## Tencent-docs 示例

**触发**: "创建腾讯文档"、"读取文档内容"、"编辑智能表"

**使用步骤**:
1. 触发 Tencent-docs 技能
2. 读取 SKILL.md 获取使用方法
3. 使用腾讯文档 API 进行操作

## Tencent-meeting-mcp 示例

**触发**: "预约腾讯会议"、"查询会议详情"、"会议录制"

**使用步骤**:
1. 触发 Tencent-meeting-mcp 技能
2. 读取 SKILL.md 获取使用方法
3. 使用腾讯会议 API 进行操作

## 常见问题解决示例

### 技能找不到
```bash
# 使用技能搜索脚本
./scripts/skill-search.sh "github"
```

### 技能不触发
1. 检查技能描述是否包含相关关键词
2. 确认只有一个技能明确适用
3. 如果多个技能适用，选择最具体的

### 技能文件丢失
1. 检查技能目录 `/root/.openclaw/workspace/skills`
2. 检查系统目录 `/usr/lib/node_modules/openclaw/skills`
3. 如果需要重新安装技能，使用 clawhub 技能