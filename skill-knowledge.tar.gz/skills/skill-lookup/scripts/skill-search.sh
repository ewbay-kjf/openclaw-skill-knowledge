#!/bin/bash
# 技能搜索脚本
# Usage: ./skill-search.sh <keyword>

KEYWORD="$1"

echo "搜索技能目录..."

# 搜索 workspace 技能
echo "Workspace 技能 (/root/.openclaw/workspace/skills):"
find /root/.openclaw/workspace/skills -type f -name "SKILL.md" | grep -i "$KEYWORD" || echo "没有找到匹配的技能"

# 搜索系统技能
echo "系统技能 (/usr/lib/node_modules/openclaw/skills):"
find /usr/lib/node_modules/openclaw/skills -type f -name "SKILL.md" | grep -i "$KEYWORD" || echo "没有找到匹配的技能"

echo "搜索完成"