---
name: skill-lookup
description: 查询 OpenClaw 所有可用技能的知识库技能。当用户询问 "你有什么技能"、"列出所有技能"、"查看技能列表"、"技能库"、"技能查询" 或类似问题时使用此技能。提供完整技能目录、调用地址、适用场景和使用规则等信息。
---

# Skill Lookup

## 概述

技能库查询技能提供一个完整的 OpenClaw 技能知识库，包括所有可用技能的详细信息、调用地址、适用场景和使用规则。这个技能可以帮助用户快速了解 OpenClaw 的功能范围，知道何时使用哪个技能，以及如何调用这些技能。

## 如何触发和使用

当用户询问以下类型的问题时触发此技能：

- "你有什么技能"
- "列出所有技能"
- "查看技能列表"
- "技能库"
- "技能查询"
- "OpenClaw 有哪些功能"
- "如何使用某个技能"

触发后，你应该：

1. **读取技能知识库文件**：读取 `/root/.openclaw/workspace/技能知识库.md` 文件获取完整技能信息
2. **根据查询提供回答**：根据用户的具体查询提供相应的技能信息
3. **可以搜索技能**：使用内置的 `find` 命令搜索技能目录
4. **解释使用规则**：说明技能触发原则和使用方法

## 技能知识库内容

技能知识库文件 `/root/.openclaw/workspace/技能知识库.md` 包含以下内容：

### 1. 可用技能列表（基于 AGENTS.md）

包括 20 个核心技能，每个技能都有：
- **描述**：技能功能和用途
- **调用地址**：技能文件位置
- **适用场景**：何时使用
- **特殊说明**：注意事项

### 2. 系统技能目录中的其他技能

列出 `/usr/lib/node_modules/openclaw/skills/` 目录中的所有技能，包括但不限于：
- 1password, apple-notes, apple-reminders, bear-notes 等

### 3. 基础工具能力（非技能）

包括 read, write, edit, exec, process, canvas, message, agents_list, sessions_list 等基础工具

### 4. 技能使用规则

- **技能触发原则**：何时读取 SKILL.md
- **技能调用约束**：API 速率限制等注意事项

## 使用方法

### 基本查询

1. **列出所有技能**：
   ```bash
   find /root/.openclaw/workspace/skills -name "SKILL.md" -type f
   find /usr/lib/node_modules/openclaw/skills -name "SKILL.md" -type f
   ```

2. **读取技能知识库**：
   ```bash
   cat /root/.openclaw/workspace/技能知识库.md
   ```

3. **查看具体技能**：
   ```bash
   cat /root/.openclaw/workspace/skills/skill-lookup/SKILL.md
   ```

### 技能搜索

如果你想搜索特定技能：

```bash
# 搜索技能目录
find /root/.openclaw/workspace/skills -type d -name "*keyword*"
find /usr/lib/node_modules/openclaw/skills -type d -name "*keyword*"
```

## 技能查询示例

### 示例 1：用户询问 "你有什么技能"

回答：列出核心技能（从 AGENTS.md 的 <available_skills> 部分）和基础工具能力

### 示例 2：用户询问 "如何使用 Github 技能"

回答：
1. Github 技能位于 `/root/.openclaw/workspace/skills/github/SKILL.md`
2. 使用 gh CLI 进行 GitHub issue、PR、CI 运行和 API 查询
3. 触发条件：当需要与 GitHub 交互时

### 示例 3：用户询问 "天气技能怎么用"

回答：
1. Weather 技能位于 `/root/.openclaw/workspace/skills/weather/SKILL.md`
2. 获取当前天气和预报，无需 API 密钥
3. 触发条件：当需要天气预报时

## 技能库更新

技能知识库需要定期更新，当：

1. **安装了新技能**：需要在技能知识库中添加新技能信息
2. **更新了技能**：需要更新相关技能的描述
3. **删除了技能**：需要从知识库中移除

你可以手动编辑 `/root/.openclaw/workspace/技能知识库.md` 文件来更新技能库。

## 脚本资源

### scripts/skill-search.sh

一个用于搜索技能目录的脚本，帮助快速定位技能文件。

```bash
#!/bin/bash
# 技能搜索脚本
# Usage: ./skill-search.sh <keyword>

KEYWORD="$1"

echo "搜索技能目录..."

# 搜索 workspace 技能
echo "Workspace 技能 (/root/.openclaw/workspace/skills):"
find /root/.openclaw/workspace/skills -type f -name "SKILL.md" | grep -i "$KEYWORD" || echo "没有找到匹配的技能"

# 搜索系统技能
echo "系统技能 (/usr/lib/node_modules/openclaw/skills):"
find /usr/lib/node_modules/openclaw/skills -type f -name "SKILL.md" | grep -i "$KEYWORD" || echo "没有找到匹配的技能"

echo "搜索完成"
```

### scripts/update-skills.sh

一个用于更新技能知识库的脚本，会自动扫描技能目录并更新知识库文件。

```bash
#!/bin/bash
# 更新技能知识库脚本
# Usage: ./update-skills.sh

echo "更新技能知识库..."

# 获取当前日期
DATE=$(date +"%Y-%m-%m %H:%M:%S")

# 创建新的知识库文件
cat > /tmp/updated-skills.md << 'EOF'
# OpenClaw 技能知识库

## 可用技能列表
EOF

# 添加核心技能
echo "添加核心技能信息..."

# 技能目录扫描（可以根据需要添加更多逻辑）

echo "知识库更新完成"
```

## 参考文档

### references/skill-categories.md

技能分类和触发指南，帮助你理解不同类型的技能和何时使用它们。

### references/usage-examples.md

技能使用示例，展示不同场景下如何使用特定技能。

## 创建日期

创建于：2025年4月21日
作者：小宝

## 更新日志

- 2025-04-21：初始版本创建
- 后续更新：定期扫描技能目录并更新知识库